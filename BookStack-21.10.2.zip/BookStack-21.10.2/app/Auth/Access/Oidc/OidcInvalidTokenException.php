<?php

namespace BookStack\Auth\Access\Oidc;

use Exception;

class OidcInvalidTokenException extends Exception
{
}
