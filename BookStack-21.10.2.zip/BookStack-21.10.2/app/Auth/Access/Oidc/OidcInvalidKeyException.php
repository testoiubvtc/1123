<?php

namespace BookStack\Auth\Access\Oidc;

class OidcInvalidKeyException extends \Exception
{
}
