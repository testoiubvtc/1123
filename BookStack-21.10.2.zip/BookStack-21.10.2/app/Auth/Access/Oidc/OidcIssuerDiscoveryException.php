<?php

namespace BookStack\Auth\Access\Oidc;

class OidcIssuerDiscoveryException extends \Exception
{
}
