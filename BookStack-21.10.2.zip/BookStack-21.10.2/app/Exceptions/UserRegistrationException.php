<?php

namespace BookStack\Exceptions;

class UserRegistrationException extends NotifyException
{
}
