<?php

namespace BookStack\Exceptions;

class LoginAttemptException extends \Exception
{
}
