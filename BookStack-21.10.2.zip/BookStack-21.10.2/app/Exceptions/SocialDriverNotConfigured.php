<?php

namespace BookStack\Exceptions;

class SocialDriverNotConfigured extends PrettyException
{
}
