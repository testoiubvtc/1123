<?php

namespace BookStack\Exceptions;

class OpenIdConnectException extends NotifyException
{
}
