<?php

namespace BookStack\Exceptions;

class LoginAttemptEmailNeededException extends LoginAttemptException
{
}
