<?php

namespace BookStack\Exceptions;

use Exception;

class MoveOperationException extends Exception
{
}
